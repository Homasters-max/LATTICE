Да. Начнём **только с шага 1 — понять LATTICE как систему целиком**. Улучшения пока не предлагаем, чтобы не смешивать baseline и redesign.

# LATTICE — системная модель

**Версия 0.1 — Conceptual Baseline**
**Дата:** 2026-09-26
**Статус:** для понимания и дальнейшего обсуждения
**Принцип:** сначала фиксируем *как система задумана сейчас*, затем отдельной версией разбираем улучшения.

---

## 1. Что такое LATTICE

LATTICE — это **семантический фундамент** для остальных компонентов системы.

Он отвечает за:

* что является объектом;
* какой у объекта тип и контекст;
* какие объекты связаны;
* какие факты утверждены;
* на каком основании они получены;
* есть ли спор;
* как восстанавливается состояние;
* какие представления можно построить поверх этого состояния.

LATTICE **не является**:

* системой поиска;
* LLM;
* workflow;
* OpenSpec;
* WARRANT;
* JEV;
* универсальной БД.

Упрощённо:

```text
                 ┌─────────────────────┐
                 │       LATTICE       │
                 │ semantic foundation │
                 └──────────┬──────────┘
                            │
             ┌──────────────┼──────────────┐
             │              │              │
          WARRANT          JEV            SRA
             │              │              │
        governance      reasoning       analysis
```

Главная идея:

> **LATTICE хранит смысл и связи, а потребители используют этот смысл для своих задач.**

---

# 2. Разделение на домены

Для понимания предлагаю разделить систему на **6 вертикальных срезов**.

Это не обязательно будущая структура каталогов. Это именно **логические домены работы системы**.

| №  | Домен                       | Главный вопрос                                        |
| -- | --------------------------- | ----------------------------------------------------- |
| D1 | **Semantic Model**          | Что существует?                                       |
| D2 | **Knowledge / Facts**       | Что мы утверждаем об объектах?                        |
| D3 | **History / Trust**         | Почему этому можно доверять и как менялось состояние? |
| D4 | **Query / Projection**      | Как получить нужное представление?                    |
| D5 | **Integration / Consumers** | Как LATTICE используется другими системами?           |
| D6 | **Evolution / Governance**  | Как меняется сама модель?                             |

И отдельно есть **сквозной механизм**:

```text
                 ┌──────────────────┐
                 │     LATTICE      │
                 │                  │
                 │  D1 Semantic     │
                 │  D2 Facts        │
                 │  D3 History      │
                 │  D4 Projection   │
                 │  D5 Integration  │
                 │  D6 Evolution    │
                 └──────────────────┘
```

---

# 3. D1 — Semantic Model

### Назначение

Определяет **что существует в мире LATTICE**.

Основные понятия:

```text
Object
 ├── identity
 ├── type
 ├── context
 └── version

Relation
 └── связь Object ↔ Object

Classification
 ├── root_kind
 ├── type
 ├── subtype
 └── properties
```

### Поток

```mermaid
flowchart LR
    A[External concept] --> B[Object]
    B --> C[Identity]
    B --> D[Classification]
    B --> E[Relations]
    C --> F[Canonical semantic model]
    D --> F
    E --> F
```

### Что здесь происходит

Например:

```text
REQ-001
    ↓
context = spec
type = requirement
root_kind = concept
```

А затем:

```text
REQ-001 ──tests──> TEST-001
REQ-001 ──part_of──> CHANGE-001
```

### Главное

**Object отвечает на вопрос:**

> «Что это?»

А не:

> «Что мы об этом думаем?»

Последнее относится уже к фактам и assertions.

---

# 4. D2 — Knowledge / Facts

Это второй слой.

Объекты сами по себе ещё ничего не утверждают.

Нужно хранить:

> **что известно об объектах.**

Для этого используется **posit**.

Упрощённо:

```text
OBJECT
   │
   │ имеет
   ▼
POSIT
   │
   ├── объект
   ├── роль
   ├── значение
   └── момент времени
```

Пример:

```text
REQ-001
   │
   └── status ──> accepted
```

или:

```text
GROUP-001
   │
   └── member ──> REQ-001
```

### Поток

```mermaid
flowchart LR
    A[Object] --> B[Fact / posit]
    C[Object] --> B
    B --> D[Value]
    B --> E[Time]
    B --> F[Ledger]
```

### Главное

**Object = существующая сущность.**

**Posit = факт о сущности.**

Это очень важное разделение LATTICE.

---

# 5. D3 — History / Trust

Здесь появляется самое интересное.

LATTICE не просто говорит:

> «REQ-001 входит в группу».

Он может хранить:

> «Агент X утверждает, что REQ-001 входит в группу, с такой-то надёжностью».

То есть:

```text
POSIT
  │
  └── ASSERTION
        ├── asserter
        └── reliability
```

### Поток

```mermaid
flowchart LR
    A[Fact] --> B[Assertion]
    B --> C[Who asserted]
    B --> D[Reliability]
    B --> E[Session / provenance]

    C --> F[Trust state]
    D --> F
    E --> F
```

На основании assertions вычисляются две разные вещи:

```text
grounding
    inferred
    observed
    declared

epistemic_state
    settled
    contested
    unresolved
```

То есть:

```text
             FACT
              │
       ┌──────┴──────┐
       ▼             ▼
   grounding    epistemic_state
       │             │
   "откуда?"      "есть спор?"
```

### Почему это важно

Не нужно делать одно поле:

```text
confidence = 0.83
```

Потому что:

```text
inferred + settled
```

и

```text
declared + contested
```

— совершенно разные состояния.

---

# 6. D4 — Query / Projection

LATTICE не должен заставлять потребителя читать весь ledger.

Из состояния строятся **projections**.

Основной поток:

```mermaid
flowchart LR
    A[Ledger] --> B[Reconstruction]
    B --> C[Current State]
    C --> D[Query]
    D --> E[Projection]
    E --> F[Consumer]
```

То есть:

```text
Ledger
  ↓
State
  ↓
Query
  ↓
Projection
```

Например потребителю WARRANT не нужен весь LATTICE.

Ему нужен:

```text
REQ-001
REQ-002
CHANGE-017
REQ-001 --tests--> TEST-031
REQ-001 --part_of--> CHANGE-017
```

Это уже **read model**.

---

# 7. D5 — Integration / Consumers

LATTICE сам по себе ничего не «решает» за потребителей.

Разные системы используют его по-разному.

```mermaid
flowchart TD
    L[LATTICE]

    L --> W[WARRANT]
    L --> J[JEV]
    L --> S[SRA]
    L --> K[Knowledge Search]
    L --> O[Other consumers]
```

### WARRANT

Использует:

```text
objects
relations
history
context
evidence links
```

для governance.

### JEV

Использует семантическое состояние для:

```text
interpretation
classification
proposal
```

Но:

> JEV не становится источником истины.

### SRA

Читает нужный подграф:

```text
LATTICE
   ↓
minimal context
   ↓
reasoning
   ↓
proposal
```

Но не мутирует canonical state напрямую.

### Главный принцип интеграции

```text
Consumer
   │
   │ read
   ▼
LATTICE
   │
   │ canonical state
   ▼
Consumer
   │
   └── proposal
```

а не:

```text
Consumer ──write──> LATTICE
```

без правил.

---

# 8. D6 — Evolution / Governance

Последний вертикальный срез — **изменение самого знания**.

Система должна уметь различать:

```text
новый объект
    ↓
новый факт
    ↓
изменение факта
    ↓
спор
    ↓
подтверждение
    ↓
новое состояние
```

### Поток

```mermaid
flowchart LR
    A[Proposal] --> B[Validation]
    B --> C[Accepted change]
    C --> D[Ledger]
    D --> E[New state]
    E --> F[Projection]
```

Важный принцип:

> состояние не редактируется напрямую — оно получается из истории.

---

# 9. Сквозной поток LATTICE

Теперь можно собрать всё вместе.

```mermaid
flowchart LR
    A[External source] --> B[Object / classification]
    B --> C[Relations]
    B --> D[Posits]

    D --> E[Assertions]
    E --> F[Ledger]

    C --> F

    F --> G[Reconstruction]
    G --> H[Current semantic state]

    H --> I[Query]
    I --> J[Projection]

    J --> K[WARRANT]
    J --> L[JEV]
    J --> M[SRA]
    J --> N[Other consumers]

    N --> O[Proposal]
    O --> P[Validation]
    P --> F
```

Это, на мой взгляд, **главная диаграмма LATTICE**.

---

# 10. Что является SSOT

Очень важно разделить:

```text
                LATTICE
                   │
             ┌─────┴─────┐
             ▼           ▼
          Ledger      Registry
             │
             ▼
          State
             │
             ▼
        Read Models
             │
             ▼
        Projections
```

### SSOT

**Canonical semantic state + его история.**

### Не SSOT

* projection;
* search index;
* Jev result;
* UI;
* cache;
* summary LLM;
* domain card.

Это защищает систему от появления нескольких конкурирующих истин.

---

# 11. Где здесь группа / snapshot

Это уже потребительский паттерн, но он хорошо показывает возможности ядра.

```mermaid
flowchart TD
    A[Objects] --> B[Group]
    B --> C[Membership posits]
    C --> D[Snapshot]

    D --> E[Jev evaluation]
    E --> F[Agent verdict]

    F --> G[Assertion]
    G --> H[Calibration]

    H --> C
```

Получается цикл:

```text
Objects
   ↓
Group
   ↓
Snapshot
   ↓
Evaluation
   ↓
Verdict
   ↓
Assertion
   ↓
Group evolution
```

Это уже основа для `kb-search`, но **не нужно делать поиск частью LATTICE**.

---

# 12. Где находится Jev

Очень важно не смешивать роли.

```text
             LATTICE
          canonical meaning
                 │
                 ▼
              JEV
       semantic interpretation
                 │
                 ▼
             PROPOSAL
                 │
                 ▼
             LATTICE
```

То есть:

> **JEV предлагает → LATTICE фиксирует после проверки.**

JEV не должен становиться вторым LATTICE.

---

# 13. Где находится агент

Агент находится **снаружи**.

```mermaid
flowchart LR
    A[Agent] --> B[Query LATTICE]
    B --> C[Semantic context]
    C --> A

    A --> D[Proposal]
    D --> E[Validation]
    E --> F[LATTICE]
```

Агент:

* читает;
* интерпретирует;
* предлагает;
* может ошибаться.

LATTICE:

* фиксирует identity;
* хранит отношения;
* хранит историю;
* различает факт и inference;
* обеспечивает воспроизводимость.

---

# 14. Вертикальные срезы системы

Если смотреть не по компонентам, а **по законченной пользовательской способности**, получаются следующие slices.

### VS-1 — Создать объект

```text
input
 → classify
 → validate
 → object
 → history
 → projection
```

### VS-2 — Связать объекты

```text
objects
 → relation
 → validate
 → history
 → read model
```

### VS-3 — Утвердить факт

```text
fact
 → assertion
 → provenance
 → trust state
```

### VS-4 — Восстановить состояние

```text
ledger
 → replay
 → current state
 → deterministic result
```

### VS-5 — Получить semantic read model

```text
state
 → query
 → projection
 → consumer
```

### VS-6 — Изменить знание

```text
proposal
 → validation
 → new fact
 → history
 → new state
```

### VS-7 — Потребитель

```text
consumer
 → query LATTICE
 → получает subgraph
 → делает свою работу
 → proposal
```

---

# 15. Самая короткая модель LATTICE

Если отбросить всю терминологию:

```text
              ЧТО?
               │
             Object
               │
              КАК?
               │
           Relation
               │
            ЧТО ЗНАЕМ?
               │
             Posit
               │
          ПОЧЕМУ ЗНАЕМ?
               │
           Assertion
               │
          КОГДА ЗНАЛИ?
               │
            History
               │
         ЧТО СЕЙЧАС?
               │
             State
               │
        ЧТО ПОКАЗАТЬ?
               │
           Projection
               │
        КТО ИСПОЛЬЗУЕТ?
               │
       WARRANT / JEV / SRA
```

---

# 16. Главное понимание после шага 1

Я бы зафиксировал **6 ключевых идей**, вокруг которых дальше будем обсуждать улучшения:

1. **Object** — identity.
2. **Posit** — факт.
3. **Assertion** — отношение к факту / основание.
4. **Ledger** — история, из которой восстанавливается состояние.
5. **Projection** — удобное представление состояния для потребителя.
6. **Consumer** — использует LATTICE, но не подменяет его.

И главный системный цикл:

```text
SOURCE
  ↓
OBJECT
  ↓
FACT
  ↓
ASSERTION
  ↓
LEDGER
  ↓
STATE
  ↓
PROJECTION
  ↓
CONSUMER
  ↓
PROPOSAL
  └──────────────→ назад
```

**На этом шаг 1 заканчиваем.** Теперь у нас есть baseline, от которого можно не спорить о деталях реализации, а отдельно пройтись по каждому потоку и спросить: **«а действительно ли здесь процесс оптимален?»**

Следующим шагом я бы взял **VS-1 → VS-7 по очереди** и для каждого сделал пару **`Current → Improved`**, не меняя остальные части системы.
